--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE kutuphanedb;
--
-- Name: kutuphanedb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE kutuphanedb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE kutuphanedb OWNER TO postgres;

\connect kutuphanedb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: kitap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitap (
    kitap_id integer NOT NULL,
    isbn character varying(50) NOT NULL,
    kitap_no character varying(25),
    kitap_adi character varying(150) NOT NULL,
    yazar_id integer,
    yayin_tarihi date,
    kitap_turu_id integer
);


ALTER TABLE public.kitap OWNER TO postgres;

--
-- Name: kitap_kitap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitap_kitap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitap_kitap_id_seq OWNER TO postgres;

--
-- Name: kitap_kitap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitap_kitap_id_seq OWNED BY public.kitap.kitap_id;


--
-- Name: odunc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.odunc (
    odunc_id integer NOT NULL,
    kitap_id integer,
    uye_id integer,
    odunc_tarihi date,
    odunc_suresi integer,
    teslim_tarihi date
);


ALTER TABLE public.odunc OWNER TO postgres;

--
-- Name: odunc_odunc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.odunc_odunc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.odunc_odunc_id_seq OWNER TO postgres;

--
-- Name: odunc_odunc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.odunc_odunc_id_seq OWNED BY public.odunc.odunc_id;


--
-- Name: tur; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tur (
    tur_id integer NOT NULL,
    kitap_turu_no character varying(50) NOT NULL,
    kitap_turu_adi character varying(50) NOT NULL
);


ALTER TABLE public.tur OWNER TO postgres;

--
-- Name: tur_tur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tur_tur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tur_tur_id_seq OWNER TO postgres;

--
-- Name: tur_tur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tur_tur_id_seq OWNED BY public.tur.tur_id;


--
-- Name: uye; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uye (
    uye_id integer NOT NULL,
    uye_isim character varying(50) NOT NULL,
    uye_soyisim character varying(50) NOT NULL,
    email character varying(50),
    cinsiyet boolean,
    elindeki_kitap_sayisi integer,
    dogum_tarihi date
);


ALTER TABLE public.uye OWNER TO postgres;

--
-- Name: uye_uye_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.uye_uye_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uye_uye_id_seq OWNER TO postgres;

--
-- Name: uye_uye_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.uye_uye_id_seq OWNED BY public.uye.uye_id;


--
-- Name: yazar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yazar (
    yazar_id integer NOT NULL,
    yazar_no character varying(50),
    kitap_yazari character varying(50)
);


ALTER TABLE public.yazar OWNER TO postgres;

--
-- Name: yazar_yazar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.yazar_yazar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.yazar_yazar_id_seq OWNER TO postgres;

--
-- Name: yazar_yazar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.yazar_yazar_id_seq OWNED BY public.yazar.yazar_id;


--
-- Name: kitap kitap_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap ALTER COLUMN kitap_id SET DEFAULT nextval('public.kitap_kitap_id_seq'::regclass);


--
-- Name: odunc odunc_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc ALTER COLUMN odunc_id SET DEFAULT nextval('public.odunc_odunc_id_seq'::regclass);


--
-- Name: tur tur_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tur ALTER COLUMN tur_id SET DEFAULT nextval('public.tur_tur_id_seq'::regclass);


--
-- Name: uye uye_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uye ALTER COLUMN uye_id SET DEFAULT nextval('public.uye_uye_id_seq'::regclass);


--
-- Name: yazar yazar_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yazar ALTER COLUMN yazar_id SET DEFAULT nextval('public.yazar_yazar_id_seq'::regclass);


--
-- Data for Name: kitap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitap (kitap_id, isbn, kitap_no, kitap_adi, yazar_id, yayin_tarihi, kitap_turu_id) FROM stdin;
\.
COPY public.kitap (kitap_id, isbn, kitap_no, kitap_adi, yazar_id, yayin_tarihi, kitap_turu_id) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: odunc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.odunc (odunc_id, kitap_id, uye_id, odunc_tarihi, odunc_suresi, teslim_tarihi) FROM stdin;
\.
COPY public.odunc (odunc_id, kitap_id, uye_id, odunc_tarihi, odunc_suresi, teslim_tarihi) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: tur; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tur (tur_id, kitap_turu_no, kitap_turu_adi) FROM stdin;
\.
COPY public.tur (tur_id, kitap_turu_no, kitap_turu_adi) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: uye; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uye (uye_id, uye_isim, uye_soyisim, email, cinsiyet, elindeki_kitap_sayisi, dogum_tarihi) FROM stdin;
\.
COPY public.uye (uye_id, uye_isim, uye_soyisim, email, cinsiyet, elindeki_kitap_sayisi, dogum_tarihi) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: yazar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yazar (yazar_id, yazar_no, kitap_yazari) FROM stdin;
\.
COPY public.yazar (yazar_id, yazar_no, kitap_yazari) FROM '$$PATH$$/3357.dat';

--
-- Name: kitap_kitap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitap_kitap_id_seq', 9, true);


--
-- Name: odunc_odunc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.odunc_odunc_id_seq', 7, true);


--
-- Name: tur_tur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tur_tur_id_seq', 8, true);


--
-- Name: uye_uye_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.uye_uye_id_seq', 10, true);


--
-- Name: yazar_yazar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.yazar_yazar_id_seq', 9, true);


--
-- Name: kitap kitap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT kitap_pkey PRIMARY KEY (kitap_id);


--
-- Name: odunc odunc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT odunc_pkey PRIMARY KEY (odunc_id);


--
-- Name: tur tur_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tur
    ADD CONSTRAINT tur_pkey PRIMARY KEY (tur_id);


--
-- Name: uye uye_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uye
    ADD CONSTRAINT uye_pkey PRIMARY KEY (uye_id);


--
-- Name: yazar yazar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yazar
    ADD CONSTRAINT yazar_pkey PRIMARY KEY (yazar_id);


--
-- Name: kitap kitap_kitap_turu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT kitap_kitap_turu_id_fkey FOREIGN KEY (kitap_turu_id) REFERENCES public.tur(tur_id) NOT VALID;


--
-- Name: kitap kitap_yazar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT kitap_yazar_id_fkey FOREIGN KEY (yazar_id) REFERENCES public.yazar(yazar_id) NOT VALID;


--
-- Name: odunc odunc_kitap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT odunc_kitap_id_fkey FOREIGN KEY (kitap_id) REFERENCES public.kitap(kitap_id) NOT VALID;


--
-- Name: odunc odunc_uye_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT odunc_uye_id_fkey FOREIGN KEY (uye_id) REFERENCES public.uye(uye_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

