--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE etrade3;
--
-- Name: etrade3; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE etrade3 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE etrade3 OWNER TO postgres;

\connect etrade3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dbo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dbo;


ALTER SCHEMA dbo OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.address (
    id integer NOT NULL,
    userid integer,
    countryid smallint,
    cityid smallint,
    townid integer,
    districtid integer,
    postalcode character varying(10),
    addresstext character varying(500)
);


ALTER TABLE dbo.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.address_id_seq OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.address_id_seq OWNED BY dbo.address.id;


--
-- Name: cities; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.cities (
    id smallint NOT NULL,
    countryid smallint,
    city character varying(50)
);


ALTER TABLE dbo.cities OWNER TO postgres;

--
-- Name: countries; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.countries (
    id smallint NOT NULL,
    country character varying(50)
);


ALTER TABLE dbo.countries OWNER TO postgres;

--
-- Name: districts; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.districts (
    id integer NOT NULL,
    townid integer,
    district character varying(50)
);


ALTER TABLE dbo.districts OWNER TO postgres;

--
-- Name: districts_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.districts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.districts_id_seq OWNER TO postgres;

--
-- Name: districts_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.districts_id_seq OWNED BY dbo.districts.id;


--
-- Name: invoicedetails; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.invoicedetails (
    id integer NOT NULL,
    invoiceid integer,
    orderdetailid integer,
    itemid integer,
    amount integer,
    unitprice numeric(20,4),
    linetotal numeric(20,4)
);


ALTER TABLE dbo.invoicedetails OWNER TO postgres;

--
-- Name: invoicedetails_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.invoicedetails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.invoicedetails_id_seq OWNER TO postgres;

--
-- Name: invoicedetails_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.invoicedetails_id_seq OWNED BY dbo.invoicedetails.id;


--
-- Name: invoices; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.invoices (
    id integer NOT NULL,
    orderid integer,
    date_ timestamp(3) without time zone,
    addressid integer,
    cargoficheno character varying(20),
    totalprice numeric(20,4)
);


ALTER TABLE dbo.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.invoices_id_seq OWNED BY dbo.invoices.id;


--
-- Name: items; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.items (
    id integer NOT NULL,
    itemcode character varying(50),
    itemname character varying(100),
    unitprice double precision,
    category1 character varying(50),
    category2 character varying(50),
    category3 character varying(50),
    category4 character varying(50),
    brand character varying(50)
);


ALTER TABLE dbo.items OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.items_id_seq OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.items_id_seq OWNED BY dbo.items.id;


--
-- Name: orderdetails; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.orderdetails (
    id integer NOT NULL,
    orderid integer,
    itemid integer,
    amount integer,
    unitprice numeric(20,4),
    linetotal numeric(20,4)
);


ALTER TABLE dbo.orderdetails OWNER TO postgres;

--
-- Name: orderdetails_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.orderdetails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.orderdetails_id_seq OWNER TO postgres;

--
-- Name: orderdetails_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.orderdetails_id_seq OWNED BY dbo.orderdetails.id;


--
-- Name: orders; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.orders (
    id integer NOT NULL,
    userid integer,
    date_ timestamp(3) without time zone,
    totalprice numeric(20,4),
    status_ smallint,
    addressid integer
);


ALTER TABLE dbo.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.orders_id_seq OWNED BY dbo.orders.id;


--
-- Name: payments; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.payments (
    id integer NOT NULL,
    orderid integer,
    paymenttype smallint,
    date_ timestamp(3) without time zone,
    isok boolean,
    approvecode character varying(100),
    paymenttotal numeric(20,4)
);


ALTER TABLE dbo.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.payments_id_seq OWNED BY dbo.payments.id;


--
-- Name: towns; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.towns (
    id integer NOT NULL,
    cityid smallint,
    town character varying(50)
);


ALTER TABLE dbo.towns OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: dbo; Owner: postgres
--

CREATE TABLE dbo.users (
    id integer NOT NULL,
    username_ character varying(50),
    password_ character varying(50),
    namesurname character varying(100),
    email character varying(100),
    gender character varying(1),
    birthdate date,
    createddate timestamp(3) without time zone,
    telnr1 character varying(15),
    telnr2 character varying(15)
);


ALTER TABLE dbo.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: dbo; Owner: postgres
--

CREATE SEQUENCE dbo.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dbo.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: dbo; Owner: postgres
--

ALTER SEQUENCE dbo.users_id_seq OWNED BY dbo.users.id;


--
-- Name: address id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.address ALTER COLUMN id SET DEFAULT nextval('dbo.address_id_seq'::regclass);


--
-- Name: districts id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.districts ALTER COLUMN id SET DEFAULT nextval('dbo.districts_id_seq'::regclass);


--
-- Name: invoicedetails id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.invoicedetails ALTER COLUMN id SET DEFAULT nextval('dbo.invoicedetails_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.invoices ALTER COLUMN id SET DEFAULT nextval('dbo.invoices_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.items ALTER COLUMN id SET DEFAULT nextval('dbo.items_id_seq'::regclass);


--
-- Name: orderdetails id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.orderdetails ALTER COLUMN id SET DEFAULT nextval('dbo.orderdetails_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.orders ALTER COLUMN id SET DEFAULT nextval('dbo.orders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.payments ALTER COLUMN id SET DEFAULT nextval('dbo.payments_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.users ALTER COLUMN id SET DEFAULT nextval('dbo.users_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.address (id, userid, countryid, cityid, townid, districtid, postalcode, addresstext) FROM stdin;
\.
COPY dbo.address (id, userid, countryid, cityid, townid, districtid, postalcode, addresstext) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: cities; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.cities (id, countryid, city) FROM stdin;
\.
COPY dbo.cities (id, countryid, city) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.countries (id, country) FROM stdin;
\.
COPY dbo.countries (id, country) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: districts; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.districts (id, townid, district) FROM stdin;
\.
COPY dbo.districts (id, townid, district) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: invoicedetails; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.invoicedetails (id, invoiceid, orderdetailid, itemid, amount, unitprice, linetotal) FROM stdin;
\.
COPY dbo.invoicedetails (id, invoiceid, orderdetailid, itemid, amount, unitprice, linetotal) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.invoices (id, orderid, date_, addressid, cargoficheno, totalprice) FROM stdin;
\.
COPY dbo.invoices (id, orderid, date_, addressid, cargoficheno, totalprice) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.items (id, itemcode, itemname, unitprice, category1, category2, category3, category4, brand) FROM stdin;
\.
COPY dbo.items (id, itemcode, itemname, unitprice, category1, category2, category3, category4, brand) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: orderdetails; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.orderdetails (id, orderid, itemid, amount, unitprice, linetotal) FROM stdin;
\.
COPY dbo.orderdetails (id, orderid, itemid, amount, unitprice, linetotal) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.orders (id, userid, date_, totalprice, status_, addressid) FROM stdin;
\.
COPY dbo.orders (id, userid, date_, totalprice, status_, addressid) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.payments (id, orderid, paymenttype, date_, isok, approvecode, paymenttotal) FROM stdin;
\.
COPY dbo.payments (id, orderid, paymenttype, date_, isok, approvecode, paymenttotal) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: towns; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.towns (id, cityid, town) FROM stdin;
\.
COPY dbo.towns (id, cityid, town) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: dbo; Owner: postgres
--

COPY dbo.users (id, username_, password_, namesurname, email, gender, birthdate, createddate, telnr1, telnr2) FROM stdin;
\.
COPY dbo.users (id, username_, password_, namesurname, email, gender, birthdate, createddate, telnr1, telnr2) FROM '$$PATH$$/3410.dat';

--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.address_id_seq', 51, true);


--
-- Name: districts_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.districts_id_seq', 51, true);


--
-- Name: invoicedetails_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.invoicedetails_id_seq', 51, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.invoices_id_seq', 51, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.items_id_seq', 51, true);


--
-- Name: orderdetails_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.orderdetails_id_seq', 51, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.orders_id_seq', 51, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.payments_id_seq', 51, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: dbo; Owner: postgres
--

SELECT pg_catalog.setval('dbo.users_id_seq', 51, true);


--
-- Name: address pk_address; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.address
    ADD CONSTRAINT pk_address PRIMARY KEY (id);


--
-- Name: cities pk_cities; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.cities
    ADD CONSTRAINT pk_cities PRIMARY KEY (id);


--
-- Name: countries pk_countries; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.countries
    ADD CONSTRAINT pk_countries PRIMARY KEY (id);


--
-- Name: districts pk_districts; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.districts
    ADD CONSTRAINT pk_districts PRIMARY KEY (id);


--
-- Name: invoicedetails pk_invoicedetails; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.invoicedetails
    ADD CONSTRAINT pk_invoicedetails PRIMARY KEY (id);


--
-- Name: invoices pk_invoices; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.invoices
    ADD CONSTRAINT pk_invoices PRIMARY KEY (id);


--
-- Name: items pk_items; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.items
    ADD CONSTRAINT pk_items PRIMARY KEY (id);


--
-- Name: orderdetails pk_orderdetails; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.orderdetails
    ADD CONSTRAINT pk_orderdetails PRIMARY KEY (id);


--
-- Name: orders pk_orders; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (id);


--
-- Name: payments pk_payments; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.payments
    ADD CONSTRAINT pk_payments PRIMARY KEY (id);


--
-- Name: towns pk_towns; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.towns
    ADD CONSTRAINT pk_towns PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: dbo; Owner: postgres
--

ALTER TABLE ONLY dbo.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: ix1; Type: INDEX; Schema: dbo; Owner: postgres
--

CREATE INDEX ix1 ON dbo.address USING btree (userid);


--
-- PostgreSQL database dump complete
--

